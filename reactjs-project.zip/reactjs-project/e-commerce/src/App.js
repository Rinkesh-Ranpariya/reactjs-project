import './App.css';
import Announcement from "./components/Announcement";
import Navbar from "./components/Navbar";
import Slider from "./components/Slider";
// import Categories from "../src/components/Categories";
// import Footer from "../src/components/Footer";
// import Newsletter from "../src/components/Newsletter";
// import Products from "../src/components/Products";


import React from 'react'

function App() {
  return (
    <div className="App">
     
      <Announcement />
      <Navbar />
      <Slider />
      {/* <Categories />
      <Products/>
      <Newsletter/>
      <Footer/> */}
   
    </div>
  );
}

export default App




