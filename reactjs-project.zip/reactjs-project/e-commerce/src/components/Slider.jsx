import { sliderItems } from "../data";
import React from "react";
import style  from "../css/slider.module.css"


function Slider() {
  return (
    <div className={style.container}>
      <div className={style.wrapper}>
        <div className={style.slide}>
          <div className={style.imgcontainer}>
            <image src={sliderItems.img} />
          </div>
          <div className={style.infocontainer}>
            <div className={style.title}>{sliderItems.title}</div>
            <div className={style.desc}>{sliderItems.desc}</div>
            <button>SHOW NOW</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Slider;
