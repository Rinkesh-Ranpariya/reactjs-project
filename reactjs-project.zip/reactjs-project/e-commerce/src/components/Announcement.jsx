import style  from "../css/announcement.module.css"

import React, { Component } from 'react'

class Announcement extends Component {
  render() {
    return (
      <div className={style.announcement}>Super Deal! Free Shipping on Orders Over $50</div>
    )
  }
}

export default Announcement
