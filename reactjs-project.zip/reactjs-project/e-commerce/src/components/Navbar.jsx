import { Badge } from "@material-ui/core";
import { Search, ShoppingCartOutlined } from "@material-ui/icons";
import React, { Component } from 'react'
import style  from "../css/navbar.module.css"



export class Navbar extends Component {
  render() {
    return (
      <div className={style.container}>
        <div className={style.wrapper}>
          <div className={style.left}>
            <div className={style.language}>EN</div>
            <div className={style.searchcontainer}>
              <input type="text" className={style.input} placeholder="Search" />
              <Search style={{ color: "gray", fontSize: 16 }} />
            </div>
          </div>
          <div className={style.center}>
            <div className={style.logo}>LAMA.</div>
          </div>
          <div className={style.right}>
            <div className={style.menuitem}>REGISTER</div>
            <div className={style.menuitem}>SIGN IN</div>
            <div className={style.menuitem}>
              <Badge badgeContent={4} color="primary">
                <ShoppingCartOutlined />
              </Badge>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Navbar