import "./App.css";
import VideoCard from "./components/VideoCard";
import reels from "./data";

function App() {
  return (
    <div className="app">
      <div className="app_videos">
        {reels.map((reel,index) => (
          <VideoCard
            key={index}
            channel={reel.channel}
            avatarSrc={reel.avatarSrc}
            song={`${reel.song.toString().slice(0, 12)}..`}
            url={reel.url}
            likes={reel.likes}
            shares={reel.shares}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
