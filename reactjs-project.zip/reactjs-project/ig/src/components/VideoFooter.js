import React, { useState } from "react";
import "../css/VideoFooter.css";
import { Button, Avatar } from "@material-ui/core";
import MusicNoteIcon from "@material-ui/icons/MusicNote";
import Ticker from "react-ticker";
import FavoriteIcon from "@material-ui/icons/Favorite";
import SendIcon from "@material-ui/icons/Send";
import MoreHorizIcon from "@material-ui/icons/MoreHoriz";
import ModeCommentIcon from "@material-ui/icons/ModeComment";
import ThumbDownAltRoundedIcon from "@material-ui/icons/ThumbDownAltRounded";
import ThumbUpRoundedIcon from "@material-ui/icons/ThumbUpRounded";

function VideoFooter({ channel, avatarSrc, song, likes, shares }) {
  const [isfollow, setIsfollow] = useState(false);
  const [likeCount, setlikeCount] = useState(0);
  const [dislikeCount, setdislikeCount] = useState(0);
  const [flagLike, setflagLike] = useState(0);
  const [flagDislike, setflagDislike] = useState(0);

  const handleFollow = () => {
    isfollow ? setIsfollow(false) : setIsfollow(true);
  };

  const handleClickLike = () => {
    if (flagLike === 0 && flagDislike === 0) {
      setflagLike(1);
      setlikeCount((pre) => pre + 1);
    }
    else if(flagLike === 1){
      setflagLike(0);
      setlikeCount((pre) => pre - 1);
    }
    else if(flagLike === 0 && flagDislike === 1) {
      if (dislikeCount > 0) {
        setdislikeCount((pre) => pre - 1);
      }
      setlikeCount((pre) => pre + 1);
      setflagLike(1);
      setflagDislike(0);
    }
  };

  const handleClickDislike = () => {
    if (flagDislike === 0 && flagLike === 0) {
      setflagDislike(1);
      setdislikeCount((pre) => pre + 1);
    }
    else if(flagDislike === 1){
      setflagDislike(0);
      setdislikeCount((pre) => pre - 1);
    }
    else if(flagLike === 1 && flagDislike === 0) {
      if (likeCount > 0) {
        setlikeCount((pre) => pre - 1);
      }
      setdislikeCount((pre) => pre + 1);
      setflagDislike(1);
      setflagLike(0);
    }
  };

  return (
    <div className="videoFooter">
      <div className="videoFooter_text">
        <Avatar src={avatarSrc} />
        <h4>
          {channel}{" "}
          <Button onClick={handleFollow}>
            {isfollow ? "Following" : "Follow"}
          </Button>{" "}
        </h4>
      </div>

      <div className="videoFooter_ticker">
        <MusicNoteIcon className="videpFooter_icon" />

        <Ticker mode="smooth">
          {({ index }) => (
            <>
              <h1>{song}</h1>
            </>
          )}
        </Ticker>
      </div>

      <div className="videoFooter_actions">
        <div className="videoFooter_actionLeft">
          <FavoriteIcon fontSize="miduam" />
          <ModeCommentIcon fontSize="miduam" />
          <SendIcon fontSize="miduam" />
          <MoreHorizIcon fontSize="miduam" />
        </div>

        <div className="videoFooter_actionRight">
          <div className="videoFooter_stat">
            <ThumbUpRoundedIcon onClick={handleClickLike} style={{color:flagLike?"red":"white"}}/>
            <p>{likeCount}</p>
          </div>

          <div className="videoFooter_stat">
            <ThumbDownAltRoundedIcon onClick={handleClickDislike} style={{color:flagDislike?"blue":"white"}}/>
            <p>{dislikeCount}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default VideoFooter;
